﻿/// <summary>
/// Summary description for Item
/// </summary>
public class Item
{
    public int ID { get; set; }

    public string Name { get; set; }

    public Item(int id, string name)
    {
        ID = id;
        Name = name;
    }
}